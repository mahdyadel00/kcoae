<!DOCTYPE html>

<html>

<head>

    <title>المكتب الثقافي الكويتي</title>

</head>

<body>

<p>{{ $details['body'] }}</p>


</body>

</html>
