@extends('cultural_center.home')

@section('cultural')


    <!-- END HEADER -->

        <div class="client-section pt-5 pb-5">
            <div class="container">
                <div class="stuff-box">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-8 col-sm-12">
                                <div class="our-team counts-2">
                                    <span class="popin"><i class="fa fa-list-alt gold" aria-hidden="true"></i>
                                        كتاب الى من يهمه الأمر </span>
                                    <div class="button">
                                        <a href="/paper" class="btn btn-button btn-button-1 blue-bg" >
                                            للمزيد</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    </div>
@endsection
